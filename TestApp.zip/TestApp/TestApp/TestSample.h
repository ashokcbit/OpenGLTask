#pragma once

void GenerateCircleVertices(double, double, double);
void GenerateFrustrumVertices(double, double, double, int, int);
void GenerateVAOs();
void DeleteBuffers();
void DrawCall();
void GetLineStripVertices();
void GetFanVertices();
//void IndexMapping();
